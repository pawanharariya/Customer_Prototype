package com.example.customer_prototype;

class MainModel {

    Integer logo;


    MainModel(Integer logo){
        this.logo=logo;

    }

    public Integer getLogo(){
        return logo;
    }

}


