package com.example.customer_prototype;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FreeTravelMap extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_free_travel_map);
    }
}
