package com.example.customer_prototype;

public class Members {


    private String issue;
    private String details;
    public Members(){

    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
